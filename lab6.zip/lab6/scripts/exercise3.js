let userName = window.prompt("What is your name?");

if (userName.length > 15) {
    window.alert("illegal name");
} else {
    window.alert("legal name");
}